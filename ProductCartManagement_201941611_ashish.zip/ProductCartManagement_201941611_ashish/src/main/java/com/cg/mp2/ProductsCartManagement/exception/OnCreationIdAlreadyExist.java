package com.cg.mp2.ProductsCartManagement.exception;

public class OnCreationIdAlreadyExist extends Exception{

	
	//exception class id already exist
	//exception thrown only when create product object
}
