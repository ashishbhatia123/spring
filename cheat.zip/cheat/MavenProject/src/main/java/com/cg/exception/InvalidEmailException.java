package com.cg.exception;

public class InvalidEmailException extends RuntimeException{

}
