package com.cg.exception;

public class InvalidNameException extends RuntimeException{

}
