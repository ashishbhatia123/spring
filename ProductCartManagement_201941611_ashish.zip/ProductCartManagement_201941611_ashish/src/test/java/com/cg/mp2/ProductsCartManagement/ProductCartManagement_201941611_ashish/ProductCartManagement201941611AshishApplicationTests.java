package com.cg.mp2.ProductsCartManagement.ProductCartManagement_201941611_ashish;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProductCartManagement201941611AshishApplicationTests {

	@Test
	public void contextLoads() {
	}

}
