package com.cg.exception;

public class InvalidMobileException extends RuntimeException{

}
