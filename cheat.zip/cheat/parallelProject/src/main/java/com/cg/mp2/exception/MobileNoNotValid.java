package com.cg.mp2.exception;

public class MobileNoNotValid extends Exception{

}
