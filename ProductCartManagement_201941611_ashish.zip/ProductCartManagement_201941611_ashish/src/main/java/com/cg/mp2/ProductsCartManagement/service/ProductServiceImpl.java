package com.cg.mp2.ProductsCartManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mp2.ProductsCartManagement.bean.Product;
import com.cg.mp2.ProductsCartManagement.exception.IdMismatchException;
import com.cg.mp2.ProductsCartManagement.exception.OnCreationIdAlreadyExist;
import com.cg.mp2.ProductsCartManagement.repo.IProductRepo;
@Service("serviceObj")
public class ProductServiceImpl implements IProductService{

	@Autowired
	IProductRepo repoObj;
	
	@Override
	public Product createProduct(Product product) throws OnCreationIdAlreadyExist {
		// TODO Auto-generated method stub
		Product p=repoObj.createProduct(product);
		if(p==null)
		{
			throw new OnCreationIdAlreadyExist();
		}
		
		return p;
	}

	@Override
	public Product updateProduct(Product product) throws IdMismatchException {
		Product p=repoObj.updateProduct(product);
		if(p==null)
		{
			throw new IdMismatchException();
		}
		
		return p;
	}

	@Override
	public Product deleteProduct(String id) throws IdMismatchException {
		// TODO Auto-generated method stub
		Product p=repoObj.deleteProduct(id);
		if(p==null)
		{
			throw new IdMismatchException();
		}
		return p;
	}

	@Override
	public List<Product> viewAllProduct() {
		// TODO Auto-generated method stub
		return repoObj.viewAllProduct();
	}

	@Override
	public Product findProduct(String id) throws IdMismatchException {
		Product p=repoObj.findProduct(id);
		if(p==null)
		{
			throw new IdMismatchException();
		}
		return p;
		
	}

}
