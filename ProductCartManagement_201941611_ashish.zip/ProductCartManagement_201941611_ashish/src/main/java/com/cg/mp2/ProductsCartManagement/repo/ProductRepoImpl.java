package com.cg.mp2.ProductsCartManagement.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;


import org.springframework.stereotype.Repository;


import com.cg.mp2.ProductsCartManagement.bean.Product;
//product repo service
@Repository("repoObj")
@Transactional
public class ProductRepoImpl implements IProductRepo {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Product createProduct(Product product) {
		// TODO Auto-generated method stub
		String id=product.getId();
		Product pro=em.find(Product.class, id);
		if(pro==null)
		{
		em.persist(product);
		return product;
		}
		else
		{
			return null;
		}
	}

	@Override
	public Product updateProduct(Product product) {
		String id=product.getId();
		Product pro=em.find(Product.class, id);
		if(pro!=null)
		{
			pro.setName(product.getName());
			pro.setModel(product.getModel());
			pro.setPrice(product.getPrice());
			return(pro);
		}
		return null;
	}

	@Override
	public Product deleteProduct(String id) {
		Product pro=em.find(Product.class, id);
		if(pro!=null)
		{
			em.remove(pro);
			return pro;
		}
		
		return null;
		
	}

	@Override
	public List<Product> viewAllProduct() {
		// TODO Auto-generated method stub
		TypedQuery<Product> query= em.createQuery("select p from Product p", Product.class);
		List<Product> list=query.getResultList();
		
		return list;
	}

	@Override
	public Product findProduct(String id) {
		Product prod=em.find(Product.class, id);
		if(prod!=null)
		{
		return prod;
		}
		return null;
	}

}
