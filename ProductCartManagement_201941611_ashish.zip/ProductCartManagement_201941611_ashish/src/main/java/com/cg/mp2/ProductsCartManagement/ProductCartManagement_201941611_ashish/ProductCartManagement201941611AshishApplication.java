package com.cg.mp2.ProductsCartManagement.ProductCartManagement_201941611_ashish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg")
@EntityScan("com.cg")
public class ProductCartManagement201941611AshishApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagement201941611AshishApplication.class, args);
	}

}
