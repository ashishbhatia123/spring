package com.cg.mp2.ProductsCartManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mp2.ProductsCartManagement.bean.Product;
import com.cg.mp2.ProductsCartManagement.exception.IdMismatchException;
import com.cg.mp2.ProductsCartManagement.exception.OnCreationIdAlreadyExist;
import com.cg.mp2.ProductsCartManagement.service.IProductService;


// controller class
@RestController
public class ProductController {

	@Autowired(required=true)
	private IProductService serviceObj;
	
	// create product method
	@RequestMapping(value="/createProduct",consumes= "application/json",produces="application/json",method=RequestMethod.POST)
	public  Product createProduct(@RequestBody Product product) throws OnCreationIdAlreadyExist {
		return serviceObj.createProduct(product);
		
	}
	//update product method
	@RequestMapping(value="/updateProduct",consumes= "application/json",produces="application/json",method=RequestMethod.PUT)
	public  Product updateProduct(@RequestBody Product product) throws IdMismatchException {
		return serviceObj.updateProduct(product);
		
	}
	//delete product method
	@RequestMapping(value="/deleteProduct/{id}",consumes= "application/json",produces="application/json",method=RequestMethod.DELETE)
	public  Product deleteProduct(@PathVariable String id) throws IdMismatchException {
		return serviceObj.deleteProduct(id);
		
	}
	// view all product
	@RequestMapping(value="/viewAllProduct",consumes= "application/json",produces="application/json",method=RequestMethod.GET)
	public  List<Product> viewAllProduct() {
		return serviceObj.viewAllProduct();
		
	}
	// fetch by id method
	@RequestMapping(value="/findProduct",produces="application/json",method=RequestMethod.GET)
	public  Product findProduct(@RequestParam("id") String id) throws IdMismatchException {
		return serviceObj.findProduct(id);
		
	}
	
	// exception if id is not founf
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="enter valid ID (i.e) id not found")
	@ExceptionHandler({IdMismatchException.class})
	public void handleIDException(){	
	}
//exception during create if id is already exist
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="enter valid ID (i.e) id already exist")
	@ExceptionHandler({OnCreationIdAlreadyExist.class})
	public void handleOnCreationIdAlreadyExistException(){	
	}
	
	
	
}
