package com.cg.mp2.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.mp2.bean.Account;
import com.cg.mp2.bean.Transactions;

public interface IWalletService {
	public abstract Account createAccount(Account accountHolder);
	public abstract BigDecimal showBalance(String mobNo);
	public abstract Account Deposit(String mobNo , BigDecimal amount);
	public abstract Account withdraw(String mobNo , BigDecimal ammount);
	public abstract List<Account> fundTransfer(String sendersMobNo, String ReciversMobNo , BigDecimal amount);
	public abstract List<Transactions> printTransaction(String mobNo);

	
	public abstract List<Account> AccountHolderNameStartWith_A();
	public abstract List<Account> WalletAmountRange(BigDecimal startAmount, BigDecimal endAmount);
	public abstract Account updateLastName(String mobNo ,String lName);
	public abstract Account deleteAccount(String mobNo);
	public abstract List<Account> deleteTransactionsTillNow(String mobNo);
    
	
	
	
}
