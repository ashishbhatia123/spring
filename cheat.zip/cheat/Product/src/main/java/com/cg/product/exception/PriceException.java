package com.cg.product.exception;

public class PriceException {

}
