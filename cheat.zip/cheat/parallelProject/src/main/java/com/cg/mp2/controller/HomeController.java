package com.cg.mp2.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mp2.bean.Account;
import com.cg.mp2.bean.Transactions;
import com.cg.mp2.exception.MobileNoNotValid;
import com.cg.mp2.exception.withdrawlAmountIsNotValid;
import com.cg.mp2.service.IWalletService;


@RestController
public class HomeController {
	@Autowired
	IWalletService serviceObj;

	@RequestMapping(value="/createAccount", consumes="Applicaation/json" ,produces="Application/json")
	public Account createAccount(@RequestBody Account accountHolder) {
		return serviceObj.createAccount(accountHolder);}
	
	@RequestMapping(value="/showBalance")
	public  BigDecimal showBalance(@RequestParam("mobileNo") String mobNo){
		return serviceObj.showBalance(mobNo);}

	@RequestMapping(value="/Deposit")
	public  Account Deposit(@RequestParam("mobileNo")String mobNo ,@RequestParam("amount") BigDecimal amount){
		return serviceObj.Deposit(mobNo, amount);}
	
	@RequestMapping(value="/withdraw" )
	public  Account withdraw(@RequestParam("mobileNo")String mobNo ,@RequestParam("amount") BigDecimal ammount){
		return serviceObj.withdraw(mobNo, ammount);}
	
	@RequestMapping(value="/fundTransfer")
	public  List<Account> fundTransfer(@RequestParam("sendersMobileNo")String sendersMobNo,@RequestParam("RecieverMobileNo") String ReciversMobNo ,@RequestParam("amount") BigDecimal amount){
		return serviceObj.fundTransfer(sendersMobNo, ReciversMobNo, amount);}
	
	@RequestMapping(value="/printTransaction{mobNo}", consumes="Applicaation/json" ,produces="Application/json")
	public  List<Transactions> printTransaction(@PathVariable String mobNo){
		return serviceObj.printTransaction(mobNo);}
	
	
	@RequestMapping(value="/accountHolderName" ,produces="Application/json")
	public  List<Account> AccountHolderNameStartWith_A(){
		return null;}
	@RequestMapping(value="/WalletAmountRange" ,produces="Application/json")
	public  List<Account> WalletAmountRange(@RequestParam("minAmount") BigDecimal startAmount,@RequestParam("maxAmount") BigDecimal endAmount){
		return null;}
	@RequestMapping(value="/updateLname" ,produces="Application/json")
	public  Account updateLastName(@RequestParam("mobileNo")String mobNo ,@RequestParam("lname")String lName) {
		return null;}
	@RequestMapping(value="/deleteAccount" ,produces="Application/json")
	public  Account deleteAccount(@RequestParam("mobileNo")String mobNo) {
		return null;}
	@RequestMapping(value="/deleteAllTransactions" ,produces="Application/json")
	public  List<Account> deleteTransactionsTillNow(@RequestParam("mobileNo")String mobNo){
		return null;}
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="enter valid mobile no")
	@ExceptionHandler({MobileNoNotValid.class})
	public void handleMobileException(){	
	}
	
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="withdrawl amount is not valid")
	@ExceptionHandler({withdrawlAmountIsNotValid.class})
	public void handleAmountException() {
	}
	
	
}