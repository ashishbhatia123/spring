package com.cg.mp2.ProductsCartManagement.service;

import java.util.List;

import com.cg.mp2.ProductsCartManagement.bean.Product;
import com.cg.mp2.ProductsCartManagement.exception.IdMismatchException;
import com.cg.mp2.ProductsCartManagement.exception.OnCreationIdAlreadyExist;

public interface IProductService {
	
	public abstract Product createProduct(Product product) throws OnCreationIdAlreadyExist;
	public abstract Product updateProduct(Product product) throws IdMismatchException;
	public abstract Product deleteProduct(String id) throws IdMismatchException;
	public abstract List<Product> viewAllProduct();
	public abstract Product findProduct(String id) throws IdMismatchException;
	

}
