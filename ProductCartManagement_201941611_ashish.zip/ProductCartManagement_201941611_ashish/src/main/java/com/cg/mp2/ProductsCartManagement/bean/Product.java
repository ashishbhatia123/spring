package com.cg.mp2.ProductsCartManagement.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;


// table name =product
//bean class

@Entity
@Table(name="product")
public class Product {
	@Column(name="id")
	@Id
	@Size(max=20)
	private  String id;
	@Column(name="name")
	@Size(max=20)
	private String name;
	@Column(name="model")
	@Size(max=20)
	private String model;
	@Column(name="price")
	private int price;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
	}
	
	
	
	
	
}
