package com.cg.mp2.ProductsCartManagement.exception;

public class IdMismatchException extends Exception {

	
//exception class idMismatchException	

}
