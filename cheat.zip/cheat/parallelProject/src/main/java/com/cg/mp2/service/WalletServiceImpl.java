package com.cg.mp2.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.mp2.bean.Account;
import com.cg.mp2.bean.Transactions;
@Service("serviceObj")
public class WalletServiceImpl implements IWalletService {

	@Override
	public Account createAccount(Account accountHolder) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigDecimal showBalance(String mobNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account Deposit(String mobNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account withdraw(String mobNo, BigDecimal ammount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> fundTransfer(String sendersMobNo, String ReciversMobNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transactions> printTransaction(String mobNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> AccountHolderNameStartWith_A() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> WalletAmountRange(BigDecimal startAmount, BigDecimal endAmount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public  Account updateLastName(String mobNo ,String lName){
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account deleteAccount(String mobNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> deleteTransactionsTillNow(String mobNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
