package com.cg.mp2.bean;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="wallet_master")
public class Wallet {
@Column(name="wallet_No")
private int walletNo;
@Column(name="wallet_balance")
private BigInteger balance;
@OneToMany(cascade=CascadeType.ALL, mappedBy="wallet" ,targetEntity=Transactions.class)

private List<Transactions> transaction_list;
public int getWalletNo() {
	return walletNo;
}
public void setWalletNo(int walletNo) {
	this.walletNo = walletNo;
}
public BigInteger getBalance() {
	return balance;
}
public void setBalance(BigInteger balance) {
	this.balance = balance;
}
public List<Transactions> getTransaction_list() {
	return transaction_list;
}
public void setTransaction_list(List<Transactions> transaction_list) {
	this.transaction_list = transaction_list;
}
@Override
public String toString() {
	return "Wallet [walletNo=" + walletNo + ", balance=" + balance + ", transaction_list=" + transaction_list + "]";
}




}