package com.cg.mp2.exception;

public class withdrawlAmountIsNotValid extends Exception {

}
