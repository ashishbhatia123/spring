package com.cg.mp2.dao;

public class WalletDAOImpl {

}
