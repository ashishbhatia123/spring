package com.cg.mp2.bean;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="transaction_master")
public class Transactions {
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tran_Id")
	private int transactionId;
	@Column(name="tran_Type")
	private String transactionType;
	@Column(name="amount")
	private BigInteger amount;
	@ManyToOne
	@JoinColumn(name="foregnKeyWallet")
	private Wallet wallet;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public BigInteger getAmount() {
		return amount;
	}
	public void setAmount(BigInteger amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", transactionType=" + transactionType + ", amount="
				+ amount + "]";
	}
	
	

}
