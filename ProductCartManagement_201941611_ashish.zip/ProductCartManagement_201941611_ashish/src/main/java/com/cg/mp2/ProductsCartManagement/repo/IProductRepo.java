package com.cg.mp2.ProductsCartManagement.repo;

import java.util.List;

import com.cg.mp2.ProductsCartManagement.bean.Product;

public interface IProductRepo {
	
	public abstract Product createProduct(Product product);
	public abstract Product updateProduct(Product product);
	public abstract Product deleteProduct(String id);
	public abstract List<Product> viewAllProduct();
	public abstract Product findProduct(String id);
	


}
